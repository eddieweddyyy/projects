import java.util.Scanner;
public class Board {

    private int width;
    private int height;
    private char [][] gameBoard;
    private int totalTurns;
    private boolean debugMode;


    public Board(int height,int width){
        this.width = width;
        this.height = height;
        gameBoard = new char[height][];

        for (int i=0; i<height;i++){
            gameBoard[i] = new char[width];
        }
        for (int row=0; row<gameBoard.length;row++){
            for (int col=0; col<gameBoard[row].length;col++){
                gameBoard[row][col] = '.';
            }
        }
    } /* Board constructor - takes in integers for height and width and constructs 2d array with dimensions
    @param height an integer representing the height of the board
    @param width an integer representing the width of the board
    */

    public void setDebugMode(boolean mode){
        this.debugMode = mode;
    }/* Setter for debugmode
    @param mode is a boolean value used to toggle debugmode on and off
    */

    public boolean getDebugMode(){
        return this.debugMode;
    }/* Getter for debugmode
    @returns boolean value representing if debug mode is on or off
    */


    public char[][] getGameBoard(){
        return this.gameBoard;
    }/* Getter that returns gameBoard array
    @returns a 2d array gameBoard which represents the connect four board
    */

    public int getHeight(){
        return this.height;
    }/* Getter that returns Board height
    @returns height an integer representing the height of the game board
    */

    public void setTotalTurns(int x){
        this.totalTurns += x;
    }/* Setter that increases the total number of turns by integer x
    @param x is an integer that is used to increment the number of terms
    */

    public int getTotalTurns(){
        return this.totalTurns;
    }/* Getter that returns the total number of turns
    @returns total number of turns as an integer
    */

    public String toString(){
        String str = "";
        for (int row=0; row<gameBoard.length;row++){
            if (row>0){
                str += "\n";
            }
            for (int col=0; col<gameBoard[row].length; col++){
                str += " " + gameBoard[row][col];
            }
        }
        return str + "\n";
    }/* toString method that prints 2d board array as a block given dimensions
    @returns a string grid of the values in a 2d array representing a game board
    */

    public void drop(int col, char player){
        for (int h = height-1; h>=0; h--){
            if (gameBoard[h][col]=='.'){
                gameBoard[h][col] = player;
                return;
            }
        }
    }/* Method drop which takes column and player input then places player character in
    the lowest available row for given column
    @param col is an integer representing the column a user wants to use on their turn
    @param player is a character representing a player
    */

    public String display(Board theBoard){
        String print = "";
        if (theBoard.getDebugMode()==false) {
            System.out.println("Type 'print' to print the board. Press 'enter' to continue without printing.");
            Scanner newScanner = new Scanner(System.in);
            print = newScanner.nextLine();
            if (print.equals("print")){
                System.out.println(theBoard);
            }
        }
        else if (theBoard.getDebugMode()==true) {
            System.out.println(theBoard);
        }
        return print;
    }/* displays the board if a player types in the print command
    or if the game is in debug mode displays the board automatically
     @params gameBoard represents a board variable of the current game
     @returns a string representing the current game board at the time it was called
    */

    public static boolean connectsFour(char player, char[][] currentBoard){
        for (int row=0; row<currentBoard.length; row++){
            for (int col=0; col<currentBoard[0].length-3; col++){
                if (currentBoard[row][col]==player &&
                        currentBoard[row][col+1] == player &&
                        currentBoard[row][col+2] == player &&
                        currentBoard[row][col+3] == player) {
                    return true;
                }
            }
        }// Checks for four in a row vertically
        for (int row=0; row<currentBoard.length-3;row++){
            for(int col=0; col<currentBoard[0].length;col++){
                if (currentBoard[row][col] == player &&
                        currentBoard[row+1][col] == player &&
                        currentBoard[row+2][col] == player &&
                        currentBoard[row+3][col] == player) {
                    return true;
                }
            }
        }// Checks for four in a row horizontally
        for (int row=3; row<currentBoard.length; row++){
            for (int col=0; col<currentBoard[0].length-3;col++){
                if (currentBoard[row][col]==player &&
                        currentBoard[row-1][col+1] == player &&
                        currentBoard[row-2][col+2] == player &&
                        currentBoard[row-3][col+3] == player) {
                    return true;
                }
            }
        }// Checks for four in a row upward diagonally
        for(int row=0; row<currentBoard.length-3;row++){
            for(int col=0; col<currentBoard[0].length-3;col++){
                if (currentBoard[row][col]==player &&
                        currentBoard[row+1][col-1] == player &&
                        currentBoard[row+2][col-2] == player &&
                        currentBoard[row+3][col-3] == player) {
                    return true;
                }
            }
        }// Checks for four in a row downward diagonally
        return false;
    }/* Checks to see if a player has four in a row on a given board
    @param player is a character value used to differentiate between players
    @param currentBoard is a 2D character array representing the current board of a connect four game
    @returns a boolean value representing if a person has won or lost
    */

    public static boolean connectsFive(char player, char[][] currentBoard){
        for (int row=0; row<currentBoard.length; row++){
            for (int col=0; col<currentBoard[0].length-4; col++){
                if (currentBoard[row][col]==player &&
                        currentBoard[row][col+1] == player &&
                        currentBoard[row][col+2] == player &&
                        currentBoard[row][col+3] == player &&
                        currentBoard[row][col+4] == player) {
                    return true;
                }
            }
        }// Checks for five in a row vertically
        for (int row=0; row<currentBoard.length-4;row++){
            for(int col=0; col<currentBoard[0].length;col++){
                if (currentBoard[row][col] == player &&
                        currentBoard[row+1][col] == player &&
                        currentBoard[row+2][col] == player &&
                        currentBoard[row+3][col] == player &&
                        currentBoard[row+4][col] == player) {
                    return true;
                }
            }
        }// Checks for five in a row horizontally
        for (int row=4; row<currentBoard.length; row++){
            for (int col=0; col<currentBoard[0].length-4;col++){
                if (currentBoard[row][col]==player &&
                        currentBoard[row-1][col+1] == player &&
                        currentBoard[row-2][col+2] == player &&
                        currentBoard[row-3][col+3] == player &&
                        currentBoard[row-4][col+4] == player) {
                    return true;
                }
            }
        }//Checks for five in a row diagonally
        for(int row=0; row>currentBoard.length-4;row++){
            for(int col=0; col>currentBoard[0].length-4;col++){
                if (currentBoard[row][col]==player &&
                        currentBoard[row+1][col-1] == player &&
                        currentBoard[row+2][col-2] == player &&
                        currentBoard[row+3][col-3] == player &&
                        currentBoard[row+4][col-4] == player) {
                    return true;
                }
            }
        }//Checks for five in a row diagonally
        return false;
    }/* Checks to see if a player has five in a row on a given board
    @param player is a character value used to differentiate between players
    @param currentBoard is a 2D character array representing the current board of a connect four expert game
    @returns a boolean value representing if a person has won or lost
    */
}
