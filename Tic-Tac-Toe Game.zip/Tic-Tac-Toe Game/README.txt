
Board
-- javac Board.java
-- java Board

Game
-- javac Game.java
-- java Game

User input is aligned with what it asks.

Game class breaks when user input for move is character, not int as it asks for.

Create random numbers: https://stackoverflow.com/questions/363681/how-do-i-generate-random-integers-within-a-specific-range-in-java

return a 2D array from toString() method: https://stackoverflow.com/questions/21011027/return-a-2d-array-from-tostring-method