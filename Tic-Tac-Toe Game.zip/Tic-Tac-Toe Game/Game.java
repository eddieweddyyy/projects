import java.util.Scanner;
import java.util.Random;
public class Game {

    public static void getAIMove(int input, Board myBoard){
        if (input==8){
            int ranNum = (int)(Math.random()*((input)-(input-1))+(input-1));
            myBoard.drop(ranNum, 'C');
        } else if (input==0) {
            int ranNum = (int)(Math.random()*((input+1)-(input))+(input));
            myBoard.drop(ranNum, 'C');
        }else{
            int ranNum = (int)(Math.random()*((input+1)-(input-1))+(input-1));
            myBoard.drop(ranNum, 'C');
        }
    }/* getAImove chooses a random number of range that it will move, based on user input that sets user's character on the board, and locates AI's character on the board.

        @param input: an input that user chooses to place their character on the board.
        @param myBoard: the board that AI's character will be located.

        @returns nothing.
    */

    public static void main(String[] args){
        System.out.println("For Expert mode enter E - For Normal mode enter N");
        Scanner myScanner = new Scanner(System.in);
        String mode = myScanner.nextLine();
        Board myBoard = new Board(6,7);
        System.out.println("For Debug Mode enter D - For Normal mode enter N");
        String debugMode = myScanner.nextLine();

        if (mode.equals("E")){
            myBoard = new Board(6,9);
            if (debugMode.equals("D")){
                myBoard.setDebugMode(true);
            } else{
                myBoard.setDebugMode(false);
            }
            while (myBoard.connectsFive('P',myBoard.getGameBoard())==false &&
                    myBoard.connectsFive('C',myBoard.getGameBoard())==false) {
                System.out.println("Enter your move between 0-8: ");
                int input = myScanner.nextInt();
                if (input > 8 || input < 0) {
                    System.out.println("Column out of range! Try again!");
                } else if (myBoard.getGameBoard()[0][input]!='.') {
                    System.out.println("Column is Full! Try again!");
                } else {
                    if (myBoard.getDebugMode() == true) {
                        myBoard.display(myBoard);
                        myBoard.drop(input, 'P');
                        myBoard.display(myBoard);
                        getAIMove(input, myBoard);
                        myBoard.setTotalTurns(1);
                        myBoard.display(myBoard);
                    } else {
                        myBoard.drop(input, 'P');
                        getAIMove(input, myBoard);
                        myBoard.setTotalTurns(1);
                        myBoard.display(myBoard);
                    }
                }

                if (myBoard.connectsFive('P',myBoard.getGameBoard())==true){
                    System.out.println("Player wins!");
                    System.out.println("It took " + myBoard.getTotalTurns() + " turns");
                } else if (myBoard.connectsFive('C',myBoard.getGameBoard())==true) {
                    System.out.println("Player loses!");
                    System.out.println("It took " + myBoard.getTotalTurns() + " turns");
                }
            }
        }

        else {
            if (debugMode.equals("D")){
                myBoard.setDebugMode(true);
            } else {
                myBoard.setDebugMode(false);
            }
            while (myBoard.connectsFour('P',myBoard.getGameBoard())==false &&
                    myBoard.connectsFour('C',myBoard.getGameBoard())==false) {
                System.out.println("Enter your move between 0-6: ");
                int input = myScanner.nextInt();
                if (input > 6 || input < 0) {
                    System.out.println("Column out of range! Try again!");
                } else if (myBoard.getGameBoard()[0][input] != '.') {
                    System.out.println("Column is Full! Try again!");
                } else {
                    if (myBoard.getDebugMode() == true) {
                        myBoard.display(myBoard);
                        myBoard.drop(input, 'P');
                        myBoard.display(myBoard);
                        getAIMove(input, myBoard);
                        myBoard.setTotalTurns(1);
                        myBoard.display(myBoard);
                    } else {
                        myBoard.drop(input, 'P');
                        getAIMove(input, myBoard);
                        myBoard.setTotalTurns(1);
                        myBoard.display(myBoard);
                    }
                }

                if (myBoard.connectsFour('P', myBoard.getGameBoard()) == true) {
                    System.out.println("Player wins!");
                    System.out.println("It took " + myBoard.getTotalTurns() + " turns");
                } else if (myBoard.connectsFour('C', myBoard.getGameBoard()) == true) {
                    System.out.println("Player loses!");
                    System.out.println("It took " + myBoard.getTotalTurns() + " turns");
                }
            }
        }
    } /* main method 1) creates a board that game will be played 2) sets debugmode or normal mode based on user input 3) sets expert or normal mode based on user input
        4) takes in user input of numbers which referrs to player's move and locates it on the board 5) counts total turn and asks user if the user wanted to print the board when it's not debug mode
        6) checks if the user input for player move is out of range or if the column is already full and if so, it goes back to choosing phase 7) checks if player or AI wins and prints the statement
        including who won, and how many turns it took based on the result.

        @returns nothing.
        */
}

