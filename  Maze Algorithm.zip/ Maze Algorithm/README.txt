
To run compile MyMaze.java and run it - then follow the scanner prompts for selecting a level

No assumptions were made

No additional features were added

No Known bugs or defects in the program

Outside Sources:

Type Error - https://stackoverflow.com/questions/29706044/type-argument-t-is-not-within-bounds-of-type-variable-tjava-generic 

Adding Pairs to Queue - https://leetcode.com/problems/binary-tree-level-order-traversal-ii/discuss/531438/java-queue-using-pairs

Adding Pairs to Queue - https://stackoverflow.com/questions/61702224/how-to-use-pair-in-a-priority-queue-and-then-return-the-value-using-the-key-as-t

Random Elements - https://www.geeksforgeeks.org/getting-random-elements-from-arraylist-in-java/

Fixing Error regarding generic types - https://stackoverflow.com/questions/46752027/java-type-parameter-x-is-not-within-its-bound-should-implement-comparablex