import java.util.Random;
import java.util.Scanner;

public class MyMaze {

    public static Cell[][] maze;
    public static int rows, cols, startRow, endRow;

    /**
     * Default constructor for MyMaze object.
     *
     * @param rows     total rows for the maze.
     * @param cols     total columns for the maze.
     * @param startRow row index of maze entrance
     * @param endRow   row index of maze exit
     */
    public MyMaze(int rows, int cols, int startRow, int endRow) {
        this.rows = rows;
        this.cols = cols;
        this.startRow = startRow;
        this.endRow = endRow;
        this.maze = new Cell[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                maze[i][j] = new Cell();
            }
        }
    }

    /**
     * Displays the maze to the user.
     */
    public void printMaze() {
        int row;
        for(row = 0; row < cols; ++row) {
            System.out.print("|--");
        }

        System.out.println("|");

        for(row = 0; row < rows; ++row) {
            if (row != startRow) {
                System.out.print("|");
            } else {
                System.out.print(" ");
            }

            int col;
            for(col = 0; col < cols; ++col) {
                if(maze[row][col].getVisited()){
                    System.out.print(" *");
                } else{
                    System.out.print("  ");
                }
                if ((col != cols - 1 || row != endRow) && maze[row][col].getRight()) {
                    System.out.print("|");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
            for(col = 0; col < cols; ++col) {
                System.out.print("|");
                if (maze[row][col].getBottom()) {
                    System.out.print("--");
                } else {
                    System.out.print("  ");
                }
            }

            System.out.println("|");
        }

    }

    public interface List<T extends Comparable<? super T>> {

        boolean add(T element);

        T get(int index);

        boolean isEmpty();

        int size();

    }
    public static class ArrayList<T extends Comparable<? super T>> implements List<T> {
        private T[] array;
        private int size;
        public ArrayList(){
            this.array = (T[]) new Comparable[2];
            this.size = 0;
        }
        public boolean add(T element){
            if(element==null){
                return false;
            }
            int i=0;
            while(array[i]!=null){
                i++;
                if (i==array.length){
                    T[] newArray = (T[]) new Comparable[array.length*2];
                    int j;
                    for(j=0;j<array.length;j++){
                        newArray[j] = array[j];
                    }
                    if (array[j-1].compareTo(element)>0){
                        newArray[j] = element;
                        size++;
                    } else{
                        newArray[j] = element;
                        size++;
                    }
                    this.array = newArray;
                    return true;
                }
            }
            if (i==0){
                array[i] = element;
                size++;
            }else if (array[i-1].compareTo(element)>0) {
                array[i] = element;
                size++;
            }else{
                array[i] = element;
                size++;
            }
            return true;
        }
        public T get(int index) {
            if (index < 0 || index > array.length - 1) {
                return null;
            } else {
                T element = (T) array[index];
                return element;
            }
        }
        public boolean isEmpty(){
            if(array[0]==null){
                return true;
            }
            return false;
        }
        public int size() {
            return size;
        }
    }

    private static class Pair implements Comparable<Pair> {
        public int row;
        public int col;

        public Pair(int rows, int cols) {
            row = rows;
            col = cols;
        }
        public void get(){
            return;
        }

        @Override
        public int compareTo(Pair o) {
            return 0;
        }
    }

        /**
         * Generates a random maze using the algorithm from the write up.
         *
         * @param level difficulty level for maze (1-3) that decides maze dimensions
         *              level 1 -> 5x5, level 2 -> 5x20, level 3 -> 20x20
         * @return MyMaze object fully generated.
         */

        public static MyMaze makeMaze(int level) {
            int ranNumR = (int) Math.random() * (5 - 0 + 1) + 0;
            int ranNumC = (int) Math.random() * (5 - 0 + 1) + 0;
            MyMaze newMaze = new MyMaze(1, 1, ranNumR, ranNumC);
            Pair newPair = new Pair(newMaze.startRow, 0);

            Stack1Gen<Pair> myStack = new Stack1Gen();//initialize a stack with the start index {startRow, 0}
            myStack.push(newPair);//

            newMaze.maze[newMaze.startRow][0].setVisited(true);

            if (level == 1) {
                newMaze = new MyMaze(5, 5, ranNumR, ranNumC);
                while (!myStack.isEmpty()) {
                    Pair currentTop = myStack.top();
                    Cell currentCell = newMaze.maze[currentTop.row][currentTop.col];

                    ArrayList<Pair> neighbours = new ArrayList<>();
                    if (currentTop.row + 1 < 5 && newMaze.maze[currentTop.row + 1][currentTop.col].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row + 1, currentTop.col));
                    }//above
                    if (currentTop.row - 1 >= 0 && newMaze.maze[currentTop.row - 1][currentTop.col].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row - 1, currentTop.col));
                    }//below
                    if (currentTop.col - 1 >= 0 && newMaze.maze[currentTop.row][currentTop.col - 1].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row, currentTop.col - 1));
                    }//left
                    if (currentTop.col + 1 < 5 && newMaze.maze[currentTop.row][currentTop.col + 1].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row, currentTop.col + 1));
                    }//right
                    if (neighbours.isEmpty()) {
                        myStack.pop();
                    } else {
                        int index = (int) (Math.random() * neighbours.size());
                        Pair indicies = neighbours.get(index);
                        myStack.push(indicies);
                        Cell selectedNeigh = MyMaze.maze[indicies.row][indicies.col];
                        selectedNeigh.setVisited(true);

                        if (indicies.row == currentTop.row + 1) {
                            currentCell.setBottom(false);
                        }//current is above neigh
                        else if (indicies.row == currentTop.row - 1) {
                            selectedNeigh.setBottom(false);
                        }//current is below neigh
                        else if (indicies.col == currentTop.col - 1) {
                            selectedNeigh.setRight(false);
                        }//neigh is left
                        else if (indicies.col == currentTop.col + 1) {
                            currentCell.setRight(false);
                        }//current is left
                    }
                }
            }
            if (level == 2) {
                newMaze = new MyMaze(5, 20, ranNumR, ranNumC);
                while (!myStack.isEmpty()) {
                    Pair currentTop = myStack.top();
                    Cell currentCell = newMaze.maze[currentTop.row][currentTop.col];

                    var neighbours = new ArrayList<Pair>();
                    if (currentTop.row + 1 < 5 && newMaze.maze[currentTop.row + 1][currentTop.col].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row + 1, currentTop.col));
                    }//above
                    if (currentTop.row - 1 >= 0 && newMaze.maze[currentTop.row - 1][currentTop.col].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row - 1, currentTop.col));
                    }//below
                    if (currentTop.col - 1 >= 0 && newMaze.maze[currentTop.row][currentTop.col - 1].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row, currentTop.col - 1));
                    }//left
                    if (currentTop.col + 1 < 20 && newMaze.maze[currentTop.row][currentTop.col + 1].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row, currentTop.col + 1));
                    }//right
                    if (neighbours.isEmpty()) {
                        myStack.pop();
                    } else {
                        int index = (int) (Math.random() * neighbours.size());
                        Pair indicies = neighbours.get(index);
                        myStack.push(indicies);
                        Cell selectedNeigh = MyMaze.maze[indicies.row][indicies.col];
                        selectedNeigh.setVisited(true);

                        if (indicies.row == currentTop.row + 1) {
                            currentCell.setBottom(false);
                        }//current is above neigh
                        else if (indicies.row == currentTop.row - 1) {
                            selectedNeigh.setBottom(false);
                        }//current is below neigh
                        else if (indicies.col == currentTop.col - 1) {
                            selectedNeigh.setRight(false);
                        }//neigh is left
                        else if (indicies.col == currentTop.col + 1) {
                            currentCell.setRight(false);
                        }//current is left
                    }
                }
            }
            if (level == 3) {
                newMaze = new MyMaze(20, 20, ranNumR, ranNumC);
                while (!myStack.isEmpty()) {
                    Pair currentTop = myStack.top();
                    Cell currentCell = newMaze.maze[currentTop.row][currentTop.col];

                    var neighbours = new ArrayList<Pair>();
                    if (currentTop.row + 1 < 20 && newMaze.maze[currentTop.row + 1][currentTop.col].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row + 1, currentTop.col));
                    }//above
                    if (currentTop.row - 1 >= 0 && newMaze.maze[currentTop.row - 1][currentTop.col].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row - 1, currentTop.col));
                    }//below
                    if (currentTop.col - 1 >= 0 && newMaze.maze[currentTop.row][currentTop.col - 1].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row, currentTop.col - 1));
                    }//left
                    if (currentTop.col + 1 < 20 && newMaze.maze[currentTop.row][currentTop.col + 1].getVisited() == false) {
                        neighbours.add(new Pair(currentTop.row, currentTop.col + 1));
                    }//right
                    if (neighbours.isEmpty()) {
                        myStack.pop();
                    } else {
                        int index = (int) (Math.random() * neighbours.size());
                        Pair indicies = neighbours.get(index);
                        myStack.push(indicies);
                        Cell selectedNeigh = MyMaze.maze[indicies.row][indicies.col];
                        selectedNeigh.setVisited(true);

                        if (indicies.row == currentTop.row + 1) {
                            currentCell.setBottom(false);
                        }//current is above neigh
                        else if (indicies.row == currentTop.row - 1) {
                            selectedNeigh.setBottom(false);
                        }//current is below neigh
                        else if (indicies.col == currentTop.col - 1) {
                            selectedNeigh.setRight(false);
                        }//neigh is left
                        else if (indicies.col == currentTop.col + 1) {
                            currentCell.setRight(false);
                        }//current is left
                    }
                }
                for (int i = 0; i < 20; i++) {
                    for (int j = 0; j < 20; j++) {
                        newMaze.maze[i][j].setVisited(false);
                    }
                }
            }
            return newMaze;
        }
//            return newMaze;
//        }

        /**
         * Solves the maze using the algorithm from the writeup.
         */
    public void solveMaze() {
        Q1Gen<Pair> que = new Q1Gen<>();
        que.add(new Pair(startRow,0));
        while (que.length() > 0){
            Pair first = que.remove();
            maze[first.row][first.col].setVisited(true);
            if (first.row == endRow && first.col == cols - 1){
                break;
            }
            var neighbours = new ArrayList<Pair>();
                if (first.row + 1 < 20 && maze[first.row + 1][first.col].getVisited() == false) {
                    neighbours.add(new Pair(first.row + 1, first.col));
                }//above
                if (first.row - 1 >= 0 && maze[first.row - 1][first.col].getVisited() == false) {
                    neighbours.add(new Pair(first.row - 1, first.col));
                }//below
                if (first.col - 1 >= 0 && maze[first.row][first.col - 1].getVisited() == false) {
                    neighbours.add(new Pair(first.row, first.col - 1));
                }//left
                if (first.col + 1 < 20 && maze[first.row][first.col + 1].getVisited() == false) {
                    neighbours.add(new Pair(first.row, first.col + 1));
                }//right
            for (int i = 0; i < neighbours.size(); i++){
                Pair index = neighbours.get(i);
                que.add(index);
            }
        }
        printMaze();
    }

    public static <T> void main(String[] args) {
//        MyMaze testMaze = makeMaze(1);
//        testMaze.printMaze();
        Scanner sc = new Scanner(System.in);
        System.out.print("Type 1,2,3 accordingly for level: ");
        int input = sc.nextInt();
        MyMaze testMaze = makeMaze(input);
        testMaze.solveMaze();
    }
}
